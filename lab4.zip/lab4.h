/* Elijah Paulman */

bool handle_args(int argc, char *argv[], bool *bonus);
bool handle_file(char *filename, struct Sim *world);
bool init();
int main(int argc, char *argv[]);
void teardown();
