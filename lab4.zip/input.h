/* Elijah Paulman */

bool good_input(FILE* file, struct Sim *world);
bool valid_input(unsigned short code);
