/* Elijah Paulman */

bool close_enough( double x1, double y1, double x2, double y2);
bool is_left_of_flag(void *data, void *helper);
void move_everyone(struct Sim *world);
