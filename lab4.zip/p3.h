/* Elijah Paulman */

bool compareStrings(void *data1, void *data2);
struct Thing* createNode(char* str);
int main();
void printList(struct Thing* head);
void sort(struct Thing **head, ComparisonFunction cf);
