// Copyright 2024 Neil Kirby
// Not for distribution without permission

#define X_POSITION	0
#define Y_POSITION	1
#define X_VELOCITY	2
#define Y_VELOCITY	3
#define JUMP_VELOCITY	4

