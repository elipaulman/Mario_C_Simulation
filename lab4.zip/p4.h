/* Elijah Paulman */

bool any(struct Thing *head, CriteriaFunction yes, void *helper);
struct Thing* createNode(char* str);
bool isMatch(void *data, void *helper);
int main();
