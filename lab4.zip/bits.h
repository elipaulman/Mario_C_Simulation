/* Elijah Paulman */

unsigned int get_VX(unsigned short code);
unsigned int get_coin_X(unsigned short code);
unsigned int get_coin_Y(unsigned short code);
unsigned int get_color(unsigned short code);
unsigned int get_jump_V(unsigned short code);
bool is_brutus(unsigned short code);
bool is_coin(unsigned short code);
bool valid_brutus(unsigned short code);
bool valid_coin(unsigned short code);
