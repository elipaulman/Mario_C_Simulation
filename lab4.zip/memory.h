/* Elijah Paulman */

void *allocate_struct(int size);
void free_struct(void *thing);
