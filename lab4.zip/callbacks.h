/* Elijah Paulman */

bool always_true(void *data, void *helper);
bool brutus_Y_order(void *data1, void * data2);
bool brutus_score_order(void *data1, void * data2);
bool coin_color_order( void *data1, void * data2);
