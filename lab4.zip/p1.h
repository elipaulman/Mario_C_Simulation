/* Elijah Paulman */

struct Thing* createNode(int dval);
void insert(struct Thing *newnode, struct Thing **p2p2change);
int main();
void printList(struct Thing* head);
