// Copyright 2024 Neil Kirby
// Not for distribution without permission

#define DELTA_TIME (1.0 / 32.0)

